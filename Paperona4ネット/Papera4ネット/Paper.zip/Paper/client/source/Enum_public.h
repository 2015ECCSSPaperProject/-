
#pragma once

enum class TEAM_COLOR
{
	ONE,
	TWO,
	NONE,
};
